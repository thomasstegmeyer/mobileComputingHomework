package com.mobilecomputinghomework.reminderLogin.ui.theme.Profile

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.mobilecomputinghomework.reminderLogin.R

@Composable
fun Profile(onBackPress: () -> Unit, navController: NavController) {


    Surface {
        Column(modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top


        ){
            val appBarColor = MaterialTheme.colors.surface.copy(alpha = 0.87f)
            ProfileAppBar(
                backgroundColor = appBarColor,
                navController = navController
            )

            Icon(imageVector = Icons.Filled.AccountCircle,
                contentDescription = stringResource(R.string.Account),
                modifier = Modifier.size(200.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Username: " + loadData(key = "username"))
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {navController.navigate("changeProfile")},
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Change user info")
            }
        }




    }

}
@Composable
private fun ProfileAppBar(
    backgroundColor: Color,
    navController: NavController
){
    TopAppBar(
        title = { IconButton(onClick = {navController.navigate("Main")}) {
            Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")

        }
        },
        backgroundColor = backgroundColor,
        actions = {
            IconButton(onClick = {navController.navigate("Login")}) {
                Icon(imageVector = Icons.Filled.ExitToApp, contentDescription ="Exit")

            }

        }
    )
}

@Composable
fun saveData(
    key: String,
    text: String
){
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("login", Context.MODE_PRIVATE)
    val editor = sharedPreferences.edit()

    editor.apply(){
        putString(key,text)
    }.apply()

}

@Composable
fun loadData(
    key: String
): String? {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("login", Context.MODE_PRIVATE)
    return sharedPreferences.getString(key,"Thomas")
}