package com.mobilecomputinghomework.reminderLogin.ui.theme.Profile

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.mobilecomputinghomework.reminderLogin.R

@Composable
fun changeProfile(onBackPress: ()-> Unit, navController: NavController) {

    //@Override
    //fun onBackPress() {
    //    navController.navigate("Main")
    //}

    val context = LocalContext.current

    val username = rememberSaveable(){
        mutableStateOf("")
    }
    val password = rememberSaveable() {
        mutableStateOf( "")
    }
    val pin = rememberSaveable() {
        mutableStateOf( "")
    }

    Surface {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top


        ) {
            val appBarColor = MaterialTheme.colors.surface.copy(alpha = 0.87f)
            changeProfileAppBar(
                backgroundColor = appBarColor,
                navController = navController
            )

            Icon(
                imageVector = Icons.Filled.AccountCircle,
                contentDescription = stringResource(R.string.Account),
                modifier = Modifier.size(200.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(value = username.value, onValueChange = {data -> username.value = data},
                label = { Text("New username") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ) )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = password.value, onValueChange = {data -> password.value = data},
                label = { Text("New password") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                )
                //visualTransformation = PasswordVisualTransformation()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = pin.value, onValueChange = {data -> pin.value = data},
                label = { Text("New pincode") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword
                )
                //visualTransformation = PasswordVisualTransformation()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {

                    val sharedPreferences = context.getSharedPreferences("login", Context.MODE_PRIVATE)
                    val editor = sharedPreferences.edit()

                    editor.apply(){
                        putString("username",username.value)
                    }.apply()
                    editor.apply(){
                        putString("password",password.value)
                    }.apply()
                    editor.apply(){
                        putString("pin",pin.value)
                    }.apply()


                    navController.navigate("Profile")
                          },
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Save")
            }



        }

    }

}

@Composable
private fun changeProfileAppBar(
    backgroundColor: Color,
    navController: NavController
){
    TopAppBar(
        title = { IconButton(onClick = {navController.navigate("Profile")}) {
            Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")

        }
        },
        backgroundColor = backgroundColor,

    )
}




