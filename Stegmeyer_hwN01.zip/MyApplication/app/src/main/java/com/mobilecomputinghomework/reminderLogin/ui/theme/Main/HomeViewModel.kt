package com.mobilecomputinghomework.reminderLogin.ui.theme.Main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobilecomputinghomework.reminderLogin.data.entity.Category
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch


class HomeViewModel: ViewModel() {
    private val _state = MutableStateFlow(MainViewState())
    private val _selectedCategory = MutableStateFlow<Category?>(null)
    val state: StateFlow<MainViewState>
        get() = _state

    fun onCategorySelected(category: Category){
        _selectedCategory.value = category
    }

    init{
        val categories = MutableStateFlow<List<Category>>(
            mutableListOf(

                Category(1,"Daily"),
                Category(2,"Weekly"),
                Category(3,"Montly"),
                Category(4,"Yearly"),
                Category(5,"Once")
            )
        )
        viewModelScope.launch{
            combine(
                categories.onEach {category ->
                    if (categories.value.isNotEmpty() && _selectedCategory.value == null){
                        _selectedCategory.value = category[0]
                    }

                },
                _selectedCategory
            ){
                categories,selectedCategory -> MainViewState(
                    categories = categories,
                    selectedCategory = selectedCategory
                )
            }.collect{
                _state.value = it
            }
        }
    }
}

//Brauche ich vermutlich nicht
data class MainViewState(
    val categories: List<Category> = emptyList(),
    val selectedCategory: Category? = null
)