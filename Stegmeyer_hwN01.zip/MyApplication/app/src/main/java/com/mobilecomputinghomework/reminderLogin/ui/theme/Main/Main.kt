package com.mobilecomputinghomework.reminderLogin.ui.theme.Main



import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.R
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding

@Composable
fun Main(
    viewModel: HomeViewModel = viewModel(),
    navController: NavController
){
    val viewState by viewModel.state.collectAsState()
    val selectedCategory = viewState.selectedCategory



    if(viewState.categories.isNotEmpty() && selectedCategory != null){
        Surface(modifier = Modifier.fillMaxSize()){
            HomeContent(
                navController = navController
            )

        }
    }

}



@Composable
fun HomeContent(
    navController: NavController,
){
    Scaffold (
        floatingActionButton = {
            FloatingActionButton(
                onClick = {navController.navigate(route = "Reminder")},
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = Color.White,
                modifier = Modifier.padding(bottom = 15.dp, end = 20.dp)
            ){
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null

                )
            }
        }
            ){
            Column(
                modifier = Modifier
                    .systemBarsPadding()
                    .fillMaxWidth()) {
                val appBarColor = MaterialTheme.colors.surface.copy(alpha = 0.87f)

                MainAppBar(
                    backgroundColor = appBarColor,
                    navController = navController
                )



                LazyColumn(
                    modifier = Modifier.padding(start = 10.dp)
                ) {
                    item {
                        Text(text = "Bring out the Garbage")
                    }
                    item {
                        Text(text = "Go climbing")
                    }
                    item {
                        Text(text = "Fell trees in neighbours garden")
                    }
                    item {
                        Text(text = "Write important mail")
                    }
                    item {
                        Text(text = "Clean out fridge")
                    }
                    item {
                        Text(text = "Catch birds")
                    }
                    item {
                        Text(text = "Buy Lamborghini")
                    }

                    items(50){
                        index ->  Text("random stuff nr. $index")
                    }
                }

            }
    }
}

@Composable
private fun MainAppBar(
        backgroundColor: Color,
        navController: NavController
    ){
    TopAppBar(
        title = { Text(
            text = stringResource(com.mobilecomputinghomework.reminderLogin.R.string.app_name),
            color = MaterialTheme.colors.primary,
            modifier = Modifier
                .padding(start = 0.dp)
                .heightIn(max = 24.dp))
        },
        backgroundColor = backgroundColor,
        actions = {

            IconButton(onClick = { navController.navigate(route = "Profile") }) {
                Icon(imageVector = Icons.Filled.AccountCircle, contentDescription = stringResource(com.mobilecomputinghomework.reminderLogin.R.string.Account))

            }
            IconButton(onClick = {navController.navigate("Login")}) {
                Icon(imageVector = Icons.Filled.ExitToApp, contentDescription ="Exit")

            }
        }
    )
}

