package com.mobilecomputinghomework.reminderLogin.ui.theme

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.mobilecomputinghomework.reminderLogin.MobileComputingHomeworkState
import com.mobilecomputinghomework.reminderLogin.rememberMobileComputingHomeworkState
import com.mobilecomputinghomework.reminderLogin.ui.theme.Login.Login
import com.mobilecomputinghomework.reminderLogin.ui.theme.Login.LoginPin
import com.mobilecomputinghomework.reminderLogin.ui.theme.Main.Main
import com.mobilecomputinghomework.reminderLogin.ui.theme.Profile.Profile
import com.mobilecomputinghomework.reminderLogin.ui.theme.Profile.changeProfile
import com.mobilecomputinghomework.reminderLogin.ui.theme.Reminder.Reminder

@Composable
fun MobileComputingHomework(
    appState: MobileComputingHomeworkState = rememberMobileComputingHomeworkState()

){
    NavHost(
        navController = appState.navController,
        startDestination ="Login"
    ){
        composable(route = "Login"){
            Login(navController = appState.navController)

        }
        composable(route = "LoginPin"){
            LoginPin(navController = appState.navController)

        }

        composable(route = "Main"){
            Main(
                navController = appState.navController
            )
        }
        composable(route = "Reminder"){
            Reminder(onBackPress = appState::navigateBack)
        }
        composable(route = "Profile"){
            //Profile(onBackPress = {fun backProfile(){appState.navController.navigate("Main")}}, navController = appState.navController)
            Profile(onBackPress = appState::navigateBack, navController = appState.navController)
        }
        composable(route = "changeProfile"){
            changeProfile(onBackPress = appState::navigateBack,navController = appState.navController)
        }
    }


}