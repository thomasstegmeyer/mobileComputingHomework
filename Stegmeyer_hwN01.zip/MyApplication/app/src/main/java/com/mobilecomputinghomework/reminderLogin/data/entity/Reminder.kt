package com.mobilecomputinghomework.reminderLogin.data.entity

import java.sql.Time
import java.util.Date

data class Reminder(
    val reminderId: Long,
    val reminderTitle: String,
    val reminderDate: Date?,
    //val reminderTime: Time,
    val reminderCategory: String
)
