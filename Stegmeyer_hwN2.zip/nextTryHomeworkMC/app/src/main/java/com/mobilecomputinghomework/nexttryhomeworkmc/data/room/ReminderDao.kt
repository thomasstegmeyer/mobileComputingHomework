package com.mobilecomputinghomework.nexttryhomeworkmc.data.room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import kotlinx.coroutines.flow.Flow

@Dao
abstract class ReminderDao {
    @Query("""
        SELECT reminders.* FROM reminders
        WHERE reminder_seen = :seen
    """)
    abstract fun remindersSeen(seen: Boolean): Flow<List<Reminder>>

    @Query("""
        SELECT reminders.* FROM reminders
        """)
    abstract suspend fun allReminders():List<Reminder>

    @Query("""
        SELECT reminders.* FROM reminders WHERE id = :id
    """)
    abstract suspend fun reminder(id: Long):Reminder


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insert(entity: Reminder): Long

    @Update(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun update(entity: Reminder)

    @Delete
    abstract suspend fun delete(entity: Reminder): Int



}