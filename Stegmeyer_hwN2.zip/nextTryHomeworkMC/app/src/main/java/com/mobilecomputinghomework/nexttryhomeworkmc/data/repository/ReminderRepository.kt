package com.mobilecomputinghomework.nexttryhomeworkmc.data.repository

import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.nexttryhomeworkmc.data.room.ReminderDao
import kotlinx.coroutines.flow.Flow

class ReminderRepository(
    private val reminderDao: ReminderDao
) {
    suspend fun remindersIfSeen(seen: Boolean): Flow<List<Reminder>>{
        return reminderDao.remindersSeen(seen)
    }

    suspend fun reminder(id:Long):Reminder{
        return reminderDao.reminder(id)
    }

    suspend fun remindersAll():List<Reminder>{
        return reminderDao.allReminders()
    }

    suspend fun addReminder(reminder: Reminder) = reminderDao.insert(reminder)

    suspend fun deleteReminder(reminder: Reminder) = reminderDao.delete(reminder)
}