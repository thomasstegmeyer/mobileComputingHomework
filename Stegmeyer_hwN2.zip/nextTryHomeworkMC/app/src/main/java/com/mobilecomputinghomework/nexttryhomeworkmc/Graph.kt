package com.mobilecomputinghomework.nexttryhomeworkmc

import android.content.Context
import androidx.room.Room
import com.mobilecomputinghomework.nexttryhomeworkmc.data.repository.ReminderRepository
import com.mobilecomputinghomework.nexttryhomeworkmc.data.room.MobileComputingDatabase


object  Graph {
    lateinit var database: MobileComputingDatabase
        private set

    val reminderRepository by lazy{
        ReminderRepository(
            reminderDao = database.reminderDao()
        )
    }

    fun provide(context: Context){
        database = Room.databaseBuilder(context,MobileComputingDatabase::class.java, "data.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}