package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder

import androidx.lifecycle.ViewModel
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.nexttryhomeworkmc.data.repository.ReminderRepository
import kotlinx.coroutines.flow.collect

class ReminderViewModel(
    private val reminderRepository: ReminderRepository = Graph.reminderRepository
): ViewModel() {


    suspend fun retrieve():List<Reminder>{
        return reminderRepository.remindersAll()
    }
    suspend fun saveReminder(reminder: Reminder):Long {
        return reminderRepository.addReminder(reminder)
    }
    suspend fun deleteReminder(reminder: Reminder):Int{
        return reminderRepository.deleteReminder(reminder = reminder)
    }

    suspend fun reminder(id:Long):Reminder{
        return reminderRepository.reminder(id)
    }

    init{

    }

}

