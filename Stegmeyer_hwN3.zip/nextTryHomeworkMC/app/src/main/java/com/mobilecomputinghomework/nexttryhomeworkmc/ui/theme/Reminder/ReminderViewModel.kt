package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.ViewModel
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import com.mobilecomputinghomework.nexttryhomeworkmc.R
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.nexttryhomeworkmc.data.repository.ReminderRepository
import com.mobilecomputinghomework.nexttryhomeworkmc.util.NotificationWorker
import kotlinx.coroutines.flow.collect
import java.util.concurrent.TimeUnit

import androidx.core.app.NotificationManagerCompat.from
import androidx.work.*
import java.sql.Timestamp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class ReminderViewModel(
    private val reminderRepository: ReminderRepository = Graph.reminderRepository,

): ViewModel() {


    suspend fun retrieve():List<Reminder>{
        return reminderRepository.remindersAll()
    }
    suspend fun saveReminder(reminder: Reminder):Long {
        if (reminder.reminder_Nofification){
            setReminderNotification(reminder = reminder)
        }
        return reminderRepository.addReminder(reminder)
    }
    suspend fun deleteReminder(reminder: Reminder):Int{
        return reminderRepository.deleteReminder(reminder = reminder)
    }

    suspend fun reminder(id:Long):Reminder{
        return reminderRepository.reminder(id)
    }


    init{
        createNotificationChannel(context = Graph.appContext)
    }

    //Reminder könnten auch im HomeViewModel gemacht werden



}
/*
private fun setOneTimeNotification(){
    val workManager = WorkManager.getInstance(Graph.appContext)
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED) //Kann sein dass ich das nicht brauche, vielleicht mal ausprobieren
        .build()

    val notificationWorker = OneTimeWorkRequestBuilder<NotificationWorker>()
        .setInitialDelay(10, TimeUnit.SECONDS)
        .setConstraints(constraints)
        .build()

    workManager.enqueue(notificationWorker)

    //Monitoring state of work
    workManager.getWorkInfoByIdLiveData(notificationWorker.id)
        .observeForever {workInfo ->
            if (workInfo.state == WorkInfo.State.SUCCEEDED){
                createSuccessNotification()
            }
        }
}*/

fun setReminderNotification(reminder: Reminder){
    val workManager = WorkManager.getInstance(Graph.appContext)
    val constraints = Constraints.Builder()
        .build()

    val pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
    val occuranceTime = LocalDateTime.parse(reminder.time, pattern)
    val current = LocalDateTime.now()
    //val timestamp: Timestamp = Timestamp.valueOf(reminder.time)
    val delay = java.time.Duration.between(current,occuranceTime).toMillis()/1000
    fun createInputData(): Data {
        return Data.Builder()
            .putString("occurrence", reminder.time)
            .build()
    }


    val notificationWorker = OneTimeWorkRequestBuilder<NotificationWorker>()
        .setInitialDelay(delay, TimeUnit.SECONDS)
        .setConstraints(constraints)
        .build()

    workManager.enqueue(notificationWorker)

    //Monitoring state of work
    workManager.getWorkInfoByIdLiveData(notificationWorker.id)
        .observeForever {workInfo ->
            if (workInfo.state == WorkInfo.State.SUCCEEDED){
                createReminderNotification(reminder)
            }
        }

}

private fun createNotificationChannel(context: Context){
    if(
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
    ){
        val name = "NotificationChannelName"
        val descriptionText = "NotificationChannelDescriptionText"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel("CHANNEL_ID",name,importance).apply {
            description = descriptionText
        }

        val notificationManager: NotificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)

    }
}

private fun createReminderNotification(reminder: Reminder){
    val notificationId = reminder.reminder_Id
    val builder = NotificationCompat.Builder(Graph.appContext, "CHANNEL_ID")
        .setSmallIcon(R.drawable.ic_launcher_background)
        .setContentTitle(reminder.reminder_Title)
        .setContentText(reminder.reminder_Message )
        .setPriority(NotificationCompat.PRIORITY_HIGH)
    with(NotificationManagerCompat.from(Graph.appContext)){
        notify(notificationId.toInt(),builder.build())
    }
}

/*

private fun createSuccessNotification(){
    val notificationId = 1
    val builder = NotificationCompat.Builder(Graph.appContext,"CHANNEL_ID")
        .setSmallIcon(R.drawable.ic_launcher_background)
        .setContentTitle("Success: Download complete")
        .setContentText("Your countdown completed successfully")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)

    with(NotificationManagerCompat.from(Graph.appContext)){
        //Notification Id is unique for each Notification that you define
        notify(notificationId, builder.build())
    }
}
*/
