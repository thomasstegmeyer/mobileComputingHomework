package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import kotlinx.coroutines.launch

@Composable
fun reminderEdit(
    navController: NavController,
    viewModel: ReminderViewModel = viewModel()
){
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("reminder", Context.MODE_PRIVATE)

    val id = rememberSaveable(){mutableStateOf(sharedPreferences.getLong("selectedReminderId",1).toLong())}
    val creatorId = rememberSaveable(){mutableStateOf(sharedPreferences.getLong("selectedReminderCreatorId",0))}
    val title = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderTitle",""))}
    val message = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderMessage",""))}
    val locationX = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderLocationX","1")?.toDouble())}
    val locationY = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderLocationY","1")?.toDouble())}
    val creationTime = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderCreationTime",""))}
    val time = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderTime",""))}
    val seen = rememberSaveable(){mutableStateOf(sharedPreferences.getBoolean("selectedReminderSeen",false))}




    Surface(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp)
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top

        )

        {

            val coroutineScope = rememberCoroutineScope()
            TopAppBar(
                title = { IconButton(onClick = {navController.navigate("reminderDetails")}) {
                    Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")

                }
                },
                actions = {
                    IconButton(onClick = {
                        coroutineScope.launch{
                            val reminder = viewModel.reminder(id.value)
                            viewModel.deleteReminder(reminder = reminder)}
                        navController.navigate("Main")
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription ="Delete")
                    }
                    //Navigation hier noch anpassen
                    IconButton(onClick = {
                        coroutineScope.launch{
                            val reminderToDelete = viewModel.reminder(id.value)
                            viewModel.deleteReminder(reminder = reminderToDelete)
                            if(title.value != null && message.value!=null && creationTime.value != null && locationY.value != null && locationX.value != null

                            ){
                                viewModel.saveReminder(Reminder(reminder_Id = id.value, reminder_Title = title.value!!, reminder_Seen = seen.value, reminder_Message = message.value!!, creator_Id = creatorId.value, creation_time = creationTime.value!!, location_x = locationX.value!!, location_y = locationY.value!!, time = time.value.toString()))
                            }

                        }

                        navController.navigate("Main")
                    }) {
                        Icon(imageVector = Icons.Filled.Done, contentDescription ="Save")

                    }

                }
            )



            title.value?.let {
                OutlinedTextField(value = it, onValueChange = {data->title.value= data.toString()},
                    label = {Text(text = "Title")},
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            message.value?.let {
                OutlinedTextField(value = it, onValueChange = {data -> message.value = data.toString()},
                    label = {Text(text = "Message")},
                    modifier = Modifier.fillMaxWidth()
                )
            }

            //Location
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(value = locationX.value.toString(), onValueChange = {data -> locationX.value = data.toDouble()},
                label = { Text("location x") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(value = locationY.value.toString(), onValueChange = {data -> locationY.value = data.toDouble()},
                label = { Text("location y") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                )
            )

            //Input Date
            Spacer(modifier = Modifier.height(10.dp))
            time.value?.let {
                OutlinedTextField(value = it, onValueChange = { data -> time.value = data.toString() },
                    label = { Text("Enter date in format: yyyy-MM-dd HH:mm") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                    )
                )
            }



        }
    }

}


@Composable
private fun ReminderEditAppBar(
    navController: NavController,
    reminderId: Long,
    viewModel: ReminderViewModel = viewModel()
){

}