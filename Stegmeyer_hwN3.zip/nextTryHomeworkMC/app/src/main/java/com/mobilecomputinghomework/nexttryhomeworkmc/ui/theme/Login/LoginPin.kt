package com.mobilecomputinghomework.reminderLogin.ui.theme.Login

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding


@Composable
fun LoginPin(
    navController: NavController
){
    Surface(modifier = Modifier.fillMaxSize()){

        val pinSaved = loadData(key = "pin")
        val usernameSaved = loadData("username")
        val username = rememberSaveable(){mutableStateOf("")}
        val pin = rememberSaveable() {mutableStateOf( "")}

        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(15.dp)
            .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top

        )

        {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "AccountIcon",
                modifier = Modifier.size(180.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = username.value, onValueChange = {data -> username.value = data},
                label = { Text("Username") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ) )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = pin.value, onValueChange = {data -> pin.value = data},
                label = { Text("Pin") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword
                ),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {navController.navigate("Login")},
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Login with password instead")
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                //onClick = {navController.navigate("Main")},
                onClick = { if(pin.value == pinSaved && username.value == usernameSaved) {navController.navigate("Main")}},
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Login")
            }
        }

    }




}


