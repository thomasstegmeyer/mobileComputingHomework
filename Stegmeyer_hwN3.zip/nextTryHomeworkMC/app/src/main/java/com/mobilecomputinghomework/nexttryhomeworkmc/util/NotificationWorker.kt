package com.mobilecomputinghomework.nexttryhomeworkmc.util

import android.content.Context
import android.view.Gravity
import android.widget.Toast
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import java.lang.Exception
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

class NotificationWorker(
    context: Context,
    userParameters: WorkerParameters
): Worker(context,userParameters) {
    override fun doWork(): Result {

        try {
//            val occurrence = inputData.getString("occurrence")
//            val pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
//            val occurenceTime = LocalDateTime.parse(occurrence, pattern)
//            var current = LocalDateTime.now()
//            var notYet = true
//
//            while (notYet) {
//                current = LocalDateTime.now()
//                if (current.isAfter(occurenceTime)){
//                    //val toast = Toast.makeText(Graph.appContext, current.isAfter(occurenceTime).toString(), Toast.LENGTH_SHORT)
//                    //toast.setGravity(Gravity.CENTER, 0, 0)
//                    //toast.show()
//                    notYet = false
//                }
//            }
            return Result.success()

        } catch (e: Exception){
            return Result.failure()
        }
    }

}