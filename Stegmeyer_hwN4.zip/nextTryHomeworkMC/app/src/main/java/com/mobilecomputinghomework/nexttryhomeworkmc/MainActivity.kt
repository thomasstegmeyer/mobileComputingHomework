package com.mobilecomputinghomework.nexttryhomeworkmc

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.NextTryHomeworkMCTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NextTryHomeworkMCTheme() {
                // A surface container using the 'background' color from the theme
                Surface(
                    color = MaterialTheme.colors.background
                ) {
                    MobileComputingHomework()
                }
            }
        }
    }


    fun saveData(
        key: String,
        text: String
    ){
        val sharedPreferences = getSharedPreferences("login", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.apply(){
            putString(key,text)
        }.apply()

    }

    fun loadData(
        key: String
    ): String? {
        val sharedPreferences = getSharedPreferences("login",Context.MODE_PRIVATE)
        return sharedPreferences.getString(key,"Thomas")
    }

}

