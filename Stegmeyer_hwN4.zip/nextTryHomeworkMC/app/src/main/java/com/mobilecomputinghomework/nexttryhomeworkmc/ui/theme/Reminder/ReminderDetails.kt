package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder

import android.annotation.SuppressLint
import android.content.Context
import android.provider.CalendarContract.*
import android.provider.CalendarContract.Events.*
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.util.*

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun reminderDetails(
    navController: NavController,
    viewModel: ReminderViewModel = viewModel()
){
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("reminder", Context.MODE_PRIVATE)
    val id = sharedPreferences.getLong("selectedReminderId",1).toLong()
    val creatorId = sharedPreferences.getLong("selectedReminderCreatorId",0)
    val title = sharedPreferences.getString("selectedReminderTitle","")
    val message = sharedPreferences.getString("selectedReminderMessage","")
    val locationX = sharedPreferences.getString("selectedReminderLocationX","1")?.toDouble()
    val locationY = sharedPreferences.getString("selectedReminderLocationY","1")?.toDouble()
    val creationTime = sharedPreferences.getString("selectedReminderCreationTime","")
    val time = sharedPreferences.getString("selectedReminderTime","")
    val seen = sharedPreferences.getBoolean("selectedReminderSeen",false)

    val coroutineScope = rememberCoroutineScope()
    val listeReminder = mutableListOf<Reminder>()

    //coroutineScope.launch{
    //    listeReminder.add(viewModel.reminder(id))
    //}







    Surface(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp)
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top

        )

        {
            var messageSpeaker = ""
            val df = DecimalFormat("#.##")
            if(time == "" && locationX == 1.toDouble()){
                messageSpeaker = title + message + " created at " + creationTime
            }else if(time != "" && locationX == 1.toDouble()){
                messageSpeaker = title + message + " will occur at "+ time + " created at " + creationTime
            }else if(time == "" && locationX != 1.toDouble()){
                messageSpeaker = title + message + " will occur at longitude" + df.format(locationX) + " and lattitude " + df.format(locationY) + " created at " + creationTime
            }else if(time != "" && locationX != 1.toDouble()){
                messageSpeaker = title + message + " will occur at "+ time +  " and at longitude" + df.format(locationX) + " lattitude " + df.format(locationY) +  " created at " + creationTime
            }

            ReminderDetailsAppBar(navController = navController, reminderId = id, messageSpeaker)

            //var reminder = listeReminder.getOrNull(0)


            Spacer(modifier = Modifier.height(12.dp))
            if (title != null) {
                Text(title)
            }
            //if (reminder != null) {
            //    Text(reminder.reminder_Title)
            //}
            Spacer(modifier = Modifier.height(10.dp))
            if (message != null) {
                Text(text = message)
            }
            Spacer(modifier = Modifier.height(10.dp))

            if(time != ""){
                Text("due on " + time)
                Spacer(modifier = Modifier.height(10.dp))
            }

            Text("created on " + creationTime)
            Spacer(modifier = Modifier.height(10.dp))
            if(locationX != 1.0){
                Text("location x / y " + locationX.toString() + " / "+ locationY.toString())
                Spacer(modifier = Modifier.height(10.dp))
            }

            if(seen){
                Text(text = "reminder has occured")
            }else{
                Text(text = "reminder has not occured yet")
            }


        }
    }

}

@Composable
private fun ReminderDetailsAppBar(
    navController: NavController,
    reminderId: Long,
    message : String?,
    viewModel: ReminderViewModel = viewModel(),

){
    val coroutineScope = rememberCoroutineScope()
    TopAppBar(
        title = { IconButton(onClick = {navController.navigate("Main")}) {
            Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")

        }
        },
        actions = {
            IconButton(onClick = {
                if(message != null){
                    lateinit var tts : TextToSpeech
                    tts = TextToSpeech(Graph.appContext,TextToSpeech.OnInitListener {
                        if(it == TextToSpeech.SUCCESS){
                            tts.language = Locale.US
                            tts.setSpeechRate(1.0f)
                            tts.speak(message, TextToSpeech.QUEUE_ADD,null)
                        }
                    })
                }

            }) {
                Icon(imageVector = Icons.Filled.PlayArrow, contentDescription ="TextToSpeech")
            }

            IconButton(onClick = {
                coroutineScope.launch{
                    val reminder = viewModel.reminder(reminderId)
                    viewModel.deleteReminder(reminder = reminder)}
                navController.navigate("Main")
            }) {
                Icon(imageVector = Icons.Filled.Delete, contentDescription ="Delete")
            }

            IconButton(onClick = {navController.navigate("reminderEdit")}) {
                Icon(imageVector = Icons.Filled.Edit, contentDescription ="Edit")

            }



        }
    )
}

