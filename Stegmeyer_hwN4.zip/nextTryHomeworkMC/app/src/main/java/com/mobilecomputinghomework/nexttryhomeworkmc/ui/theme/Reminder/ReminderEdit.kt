package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.google.android.gms.maps.model.LatLng
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun reminderEdit(
    navController: NavController,
    viewModel: ReminderViewModel = viewModel()
){
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("reminder", Context.MODE_PRIVATE)

    val id = rememberSaveable(){mutableStateOf(sharedPreferences.getLong("selectedReminderId",1).toLong())}
    val creatorId = rememberSaveable(){mutableStateOf(sharedPreferences.getLong("selectedReminderCreatorId",0))}
    val title = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderTitle",""))}
    val message = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderMessage",""))}
    val locationX = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderLocationX","1")?.toDouble())}
    val locationY = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderLocationY","1")?.toDouble())}
    val creationTime = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderCreationTime",""))}
    val time = rememberSaveable(){mutableStateOf(sharedPreferences.getString("selectedReminderTime",""))}
    val seen = rememberSaveable(){mutableStateOf(sharedPreferences.getBoolean("selectedReminderSeen",false))}

    if(locationX.value == 1.toDouble()){
        locationX.value == 0.toDouble()
    }
    if(locationY.value == 1.toDouble()){
        locationY.value == 0.toDouble()
    }

    val latlng = navController
        .currentBackStackEntry
        ?.savedStateHandle
        ?.getLiveData<LatLng>("location_data")
        ?.value

    if(latlng != null){
        locationX.value = latlng.longitude
        locationY.value = latlng.latitude
    }

    Surface(modifier = Modifier.fillMaxSize()) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp)
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top

        )

        {

            val coroutineScope = rememberCoroutineScope()
            TopAppBar(
                title = { IconButton(onClick = {navController.navigate("reminderDetails")}) {
                    Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")

                }
                },
                actions = {
                    IconButton(onClick = {
                        coroutineScope.launch{
                            val reminder = viewModel.reminder(id.value)
                            viewModel.deleteReminder(reminder = reminder)}
                        navController.navigate("Main")
                    }) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription ="Delete")
                    }
                    //Navigation hier noch anpassen
                    IconButton(onClick = {
                        coroutineScope.launch{

                            val reminderToDelete = viewModel.reminder(id.value)
                            val reminding = reminderToDelete.reminder_Nofification
                            viewModel.deleteReminder(reminder = reminderToDelete)


                            val current = LocalDateTime.now()
                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                            val now = current.format(formatter)
                            if(time.value == "" && latlng == null){
                                val reminder = title.value?.let { message.value?.let { it1 -> Reminder(creator_Id = id.value, reminder_Title = it, reminder_Message = it1, time = null, location_x = null, location_y = null, reminder_Seen = true, creation_time = now, reminder_Nofification = reminding) } }
                                if (reminder != null) {
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }
                            }else if(time.value == ""){
                                val reminder = title.value?.let { message.value?.let { it1 -> Reminder(creator_Id = id.value, reminder_Title = it, reminder_Message = it1, time = null, location_x = latlng?.longitude, location_y = latlng?.latitude, reminder_Seen = false, creation_time = now, reminder_Nofification = reminding) } }
                                if (reminder != null) {
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }
                            }else if (latlng == null){
                                val reminder = title.value?.let { message.value?.let { it1 -> Reminder(creator_Id = id.value, reminder_Title = it, reminder_Message = it1,time = time.value, location_x = null, location_y = null, reminder_Seen = false, creation_time = now, reminder_Nofification = reminding) } }
                                if (reminder != null) {
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }
                            }else {
                                val reminder = title.value?.let { message.value?.let { it1 -> Reminder(creator_Id = id.value, reminder_Title = it, reminder_Message = it1,time = time.value, location_x = latlng?.longitude, location_y = latlng?.latitude, reminder_Seen = false, creation_time = now, reminder_Nofification = reminding) } }
                                if (reminder != null) {
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }
                            }

                        }

                        navController.navigate("Main")
                    }) {
                        Icon(imageVector = Icons.Filled.Done, contentDescription ="Save")

                    }

                }
            )



            title.value?.let {
                OutlinedTextField(value = it, onValueChange = {data->title.value= data.toString()},
                    label = {Text(text = "Title")},
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            message.value?.let {
                OutlinedTextField(value = it, onValueChange = {data -> message.value = data.toString()},
                    label = {Text(text = "Message")},
                    modifier = Modifier.fillMaxWidth()
                )
            }

            //Location
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(value = locationX.value.toString(), onValueChange = {data -> locationX.value = data.toDouble()},
                label = { Text("location x") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(value = locationY.value.toString(), onValueChange = {data -> locationY.value = data.toDouble()},
                label = { Text("location y") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                )
            )

            OutlinedButton(onClick = { navController.navigate("maps")},modifier = Modifier.fillMaxWidth()) {
                Text(text = "change location")
            }

            //Input Date
            Spacer(modifier = Modifier.height(10.dp))
            time.value?.let {
                OutlinedTextField(value = it, onValueChange = { data -> time.value = data.toString() },
                    label = { Text("Enter date in format: yyyy-MM-dd HH:mm") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                    )
                )
            }



        }
    }

}


@Composable
private fun ReminderEditAppBar(
    navController: NavController,
    reminderId: Long,
    viewModel: ReminderViewModel = viewModel()
){

}