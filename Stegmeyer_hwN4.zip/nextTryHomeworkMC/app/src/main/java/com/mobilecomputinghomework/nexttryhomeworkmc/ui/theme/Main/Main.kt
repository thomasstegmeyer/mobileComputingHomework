package com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Main



import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.ktx.utils.sphericalDistance
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder.ReminderViewModel
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

@Composable
fun Main(
    navController: NavController,
    viewModel: ReminderViewModel = viewModel()
){



    Surface(modifier = Modifier.fillMaxSize()){
        HomeContent(
            navController = navController
        )

    }


}



@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun HomeContent(
    navController: NavController,
    viewModel: ReminderViewModel = viewModel()
){

    val listeReminder = mutableListOf<Reminder>()
    val coroutineScope = rememberCoroutineScope()

    val context = LocalContext.current

    val sharedPreferences = context.getSharedPreferences("reminderSeen", Context.MODE_PRIVATE)
    val showAll = sharedPreferences.getBoolean("showAll",false)
    val editor = sharedPreferences.edit()

    coroutineScope.launch{
        viewModel.retrieve().onEach {

            reminder-> run{
                val current = LocalDateTime.now()
                var occurrenceTime = LocalDateTime.now()
                if(reminder.time != null){
                    val occurrence = reminder.time

                    val pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                    val occurrenceTime = LocalDateTime.parse(occurrence, pattern)
                }

                if (current.isAfter(occurrenceTime) && !reminder.reminder_Seen) {
                    val newReminder = Reminder(
                        reminder_Id = reminder.reminder_Id,
                        creator_Id = reminder.creator_Id,
                        reminder_Title = reminder.reminder_Title,
                        reminder_Message = reminder.reminder_Message,
                        location_x = reminder.location_x,
                        location_y = reminder.location_y,
                        time = reminder.time,
                        creation_time = reminder.creation_time,
                        reminder_Seen = true,
                        reminder_Nofification = reminder.reminder_Nofification
                    )
                    viewModel.deleteReminder(reminder)
                    viewModel.saveReminder(newReminder)
                    listeReminder.add(newReminder)
                }else if(reminder.location_x != null && reminder.location_y != null && Graph.virtualLocation != null && Graph.currentLocation != null){
                    var actuallyThere: Boolean = false
                    var virtuallyThere: Boolean = false
                    val location = LatLng(reminder.location_y, reminder.location_x)
                    virtuallyThere = Graph.virtualLocation!!.sphericalDistance(location) < 20
                    actuallyThere = Graph.currentLocation!!.sphericalDistance(location) < 20
                    if ((actuallyThere || virtuallyThere) && !reminder.reminder_Seen) {
                        val newReminder = Reminder(
                            reminder_Id = reminder.reminder_Id,
                            creator_Id = reminder.creator_Id,
                            reminder_Title = reminder.reminder_Title,
                            reminder_Message = reminder.reminder_Message,
                            location_x = reminder.location_x,
                            location_y = reminder.location_y,
                            time = reminder.time,
                            creation_time = reminder.creation_time,
                            reminder_Seen = true,
                            reminder_Nofification = reminder.reminder_Nofification
                        )
                        viewModel.deleteReminder(reminder)
                        viewModel.saveReminder(newReminder)
                        listeReminder.add(newReminder)

                    }
                } else if(reminder.reminder_Seen){
                    listeReminder.add(reminder)
                }else if(showAll) {
                    listeReminder.add(reminder)
                }



            }





        }

    }
    Scaffold (
        floatingActionButton = {
            FloatingActionButton(
                onClick = {navController.navigate(route = "Reminder")},
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = Color.White,
                modifier = Modifier.padding(bottom = 15.dp, end = 20.dp)
            ){
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null

                )
            }
        }
            ){

            Column(
                modifier = Modifier
                    .systemBarsPadding()
                    .fillMaxWidth()) {
                val appBarColor = MaterialTheme.colors.surface.copy(alpha = 0.87f)

                MainAppBar(
                    backgroundColor = appBarColor,
                    navController = navController
                )

                ConstraintLayout() {
                    val(text,button) = createRefs()
                    Text(
                        text = "Show all reminders",
                        style = MaterialTheme.typography.subtitle1,
                        modifier = Modifier.constrainAs(text){
                            linkTo(
                                start = parent.start,
                                end = button.start,
                                startMargin = 24.dp,
                                endMargin = 210.dp,
                                bias = 0f
                            )
                            top.linkTo(parent.top,margin = 10.dp)
                            bottom.linkTo(parent.bottom, 10.dp)
                            width = Dimension.preferredWrapContent
                        }
                    )
                    Switch(checked = showAll,
                        modifier = Modifier.constrainAs(button){
                            top.linkTo(parent.top, margin = 10.dp)
                            bottom.linkTo(parent.bottom, 10.dp)
                            end.linkTo(parent.end)
                        },
                        onCheckedChange = {
                        editor.apply(){
                            putBoolean("showAll",it)
                        }.apply()
                        navController.navigate("Main")
                    })
                }

                ReminderList(listeReminder, context = context, navController = navController)




            }
    }
}

@Composable
private fun MainAppBar(
        backgroundColor: Color,
        navController: NavController
    ){
    TopAppBar(
        title = { Text(
            text = "Remind Me",
            color = MaterialTheme.colors.primary,
            modifier = Modifier
                .padding(start = 0.dp)
                .heightIn(max = 24.dp))
        },
        backgroundColor = backgroundColor,
        actions = {

            IconButton(onClick = {navController.navigate(route = "selectLocation")}) {
                Icon(imageVector = Icons.Filled.LocationOn, contentDescription = "")
            }

            IconButton(onClick = { navController.navigate(route = "Profile") }) {
                Icon(imageVector = Icons.Filled.AccountCircle, contentDescription = "")

            }
            IconButton(onClick = {navController.navigate("Login")}) {
                Icon(imageVector = Icons.Filled.ExitToApp, contentDescription ="Exit")

            }
        }
    )
}


@Composable
fun ReminderList(
    list: List<Reminder>,
    navController: NavController,
    context: Context
){
    LazyColumn(
        contentPadding = PaddingValues(0.dp),
        verticalArrangement = Arrangement.Center
    ){
        items(list) { item -> ReminderListItem(
            reminder = item,
            onClick = {},
            modifier = Modifier.fillParentMaxWidth(),
            navController = navController,
            context = context
        )
        }
    }
}

@Composable
fun ReminderListItem(
    reminder: Reminder,
    onClick: ()->Unit,
    modifier: Modifier = Modifier,
    navController: NavController,
    context: Context
){
    ConstraintLayout(modifier = modifier.clickable { onClick() }) {
        val(divider, reminderTitle, icon) = createRefs()
        Divider(
            Modifier.constrainAs(divider){
                top.linkTo(parent.top)
                centerHorizontallyTo(parent)
                width = Dimension.fillToConstraints
            }
        )

        //title
        Text(
            text = reminder.reminder_Title,
            maxLines = 1,
            style = MaterialTheme.typography.subtitle1,
            modifier = Modifier.constrainAs(reminderTitle){
                linkTo(
                    start = parent.start,
                    end = icon.start,
                    startMargin = 24.dp,
                    endMargin = 16.dp,
                    bias = 0f
                )
                top.linkTo(parent.top,margin = 10.dp)
                width = Dimension.preferredWrapContent
            }
        )





        //icon
        IconButton(
            onClick = {
                val sharedPreferences = context.getSharedPreferences("reminder", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()

                editor.apply(){
                    putLong("selectedReminderId",reminder.reminder_Id)
                }.apply()
                editor.apply(){
                    putLong("selectedReminderCreatorId",reminder.creator_Id)
                }.apply()
                editor.apply(){
                    putString("selectedReminderTitle",reminder.reminder_Title)
                }.apply()
                editor.apply(){
                    putString("selectedReminderMessage",reminder.reminder_Message)
                }.apply()
                if(reminder.location_x != null && reminder.location_y != null){
                    editor.apply(){
                        putString("selectedReminderLocationX",reminder.location_x.toString())
                    }.apply()
                    editor.apply(){
                        putString("selectedReminderLocationY",reminder.location_y.toString())
                    }.apply()
                }else{
                    editor.apply(){
                        putString("selectedReminderLocationX",1.toString())
                    }.apply()
                    editor.apply(){
                        putString("selectedReminderLocationY",1.toString())
                    }.apply()
                }

                editor.apply(){
                    putString("selectedReminderCreationTime",reminder.creation_time)
                }.apply()
                if(reminder.time != null){
                    editor.apply(){
                        putString("selectedReminderTime",reminder.time)
                    }.apply()
                }else {
                    editor.apply(){
                        putString("selectedReminderTime","")
                    }.apply()
                }

                editor.apply(){
                    putBoolean("selectedReminderSeen",reminder.reminder_Seen)
                }.apply()



                navController.navigate("reminderDetails")
            },
            modifier = Modifier
                .size(50.dp)
                .padding(6.dp)
                .constrainAs(icon) {
                    top.linkTo(parent.top, margin = 10.dp)
                    bottom.linkTo(parent.bottom, 10.dp)
                    end.linkTo(parent.end)
                }
        ) {
            Icon(
                imageVector = Icons.Filled.Info ,
                contentDescription = ""
            )
        }

    }
}


