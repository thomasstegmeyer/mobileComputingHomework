package com.mobilecomputinghomework.reminderLogin.ui.theme.Login

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation




@Composable
fun Login(
    navController: NavController
){
    Surface(modifier = Modifier.fillMaxSize()){

        val passwordSaved = loadData(key = "password")
        val usernameSaved = loadData("username")
        val username = rememberSaveable(){mutableStateOf("")}
        val password = rememberSaveable() {mutableStateOf( "")}

        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(15.dp)
            .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top

            )

        {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "AccountIcon",
                modifier = Modifier.size(180.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = username.value, onValueChange = {data -> username.value = data},
                label = {Text("Username")},
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ) )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = password.value, onValueChange = {data -> password.value = data},
                label = {Text("Password")},
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
            visualTransformation = PasswordVisualTransformation()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {navController.navigate("LoginPin")},
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Login with pincode instead")
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                //onClick = {navController.navigate("Main")},
                onClick = { if(password.value == passwordSaved && username.value == usernameSaved) {navController.navigate("Main")}},
                enabled = true,
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small
            ) {
                Text(text = "Login")
            }
        }

    }




}


@Composable
fun saveData(
    key: String,
    text: String
){
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("login", Context.MODE_PRIVATE)
    val editor = sharedPreferences.edit()

    editor.apply(){
        putString(key,text)
    }.apply()

}

@Composable
fun loadData(
    key: String
): String? {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("login",Context.MODE_PRIVATE)
    return if (key == "pin") {
        sharedPreferences.getString(key, "1234")
    }
    else{
        sharedPreferences.getString(key,"Thomas")
    }

}


