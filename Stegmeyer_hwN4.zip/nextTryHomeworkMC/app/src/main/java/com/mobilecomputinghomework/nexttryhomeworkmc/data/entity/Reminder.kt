package com.mobilecomputinghomework.nexttryhomeworkmc.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDateTime

@Entity(
    tableName = "reminders",
    indices = [
        Index("id", unique = true)
    ]
)
data class Reminder(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val reminder_Id: Long = 0,
    @ColumnInfo(name = "reminder_creator") val creator_Id: Long,
    @ColumnInfo(name = "reminder_title") val reminder_Title: String,
    @ColumnInfo(name = "reminder_message") val reminder_Message: String,
    @ColumnInfo(name = "reminder_location_x") val location_x: Double?,
    @ColumnInfo(name = "reminder_location_y") val location_y: Double?,
    @ColumnInfo(name = "reminder_time") val time: String?,
    @ColumnInfo(name = "creation_time") val creation_time: String,
    @ColumnInfo(name = "reminder_seen") val reminder_Seen: Boolean,
    @ColumnInfo(name = "reminder_notification") val reminder_Nofification: Boolean = false,
    )
