package com.mobilecomputinghomework.nexttryhomeworkmc.util

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.ktx.utils.sphericalDistance
import com.mobilecomputinghomework.nexttryhomeworkmc.Graph
import java.lang.Exception

class LocationReminderNotificationWorker(
    context: Context,
    userParameters: WorkerParameters
) : Worker(context, userParameters) {

    override fun doWork(): Result {

        try {

            var actuallyThere: Boolean = false
            var virtuallyThere: Boolean = false
            val location = LatLng(inputData.getString("lat")!!.toDouble(), inputData.getString("long")!!.toDouble())


            while(true){

                if(Graph.currentLocation != null){
                    actuallyThere = Graph.currentLocation!!.sphericalDistance(location) < 20
                }
                if(Graph.virtualLocation != null){
                    virtuallyThere = Graph.virtualLocation!!.sphericalDistance(location) < 20

                }


                if(actuallyThere || virtuallyThere){
                    break
                }
            }

            return Result.success()

        } catch (e: Exception){
            return Result.failure()
        }

    }
}