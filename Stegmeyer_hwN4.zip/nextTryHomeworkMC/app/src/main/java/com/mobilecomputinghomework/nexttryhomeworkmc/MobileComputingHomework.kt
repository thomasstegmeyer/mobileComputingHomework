package com.mobilecomputinghomework.nexttryhomeworkmc

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.reminderLogin.ui.theme.Login.Login
import com.mobilecomputinghomework.reminderLogin.ui.theme.Login.LoginPin
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Main.Main
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder.reminderDetails
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder.reminderEdit
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.maps.ReminderLocation
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.maps.VirtualLocation
import com.mobilecomputinghomework.reminderLogin.ui.theme.Profile.Profile
import com.mobilecomputinghomework.reminderLogin.ui.theme.Profile.changeProfile
import com.mobilecomputinghomework.reminderLogin.ui.theme.Reminder.ReminderDisplay

@Composable
fun MobileComputingHomework(
    appState: MobileComputingHomeworkState = rememberMobileComputingHomeworkState()

){
    NavHost(
        navController = appState.navController,
        startDestination ="Main"
    ){
        composable(route = "Login"){
            Login(navController = appState.navController)

        }
        composable(route = "LoginPin"){
            LoginPin(navController = appState.navController)

        }

        composable(route = "Main"){
            Main(
                navController = appState.navController
            )
        }
        composable(route = "Reminder"){
            ReminderDisplay(onBackPress = appState::navigateBack, navController = appState.navController)
        }
        composable(route = "Profile"){
            //Profile(onBackPress = {fun backProfile(){appState.navController.navigate("Main")}}, navController = appState.navController)
            Profile(onBackPress = appState::navigateBack, navController = appState.navController)
        }
        composable(route = "changeProfile"){
            changeProfile(onBackPress = appState::navigateBack,navController = appState.navController)
        }
        composable(route = "reminderDetails"){
            reminderDetails(navController = appState.navController)
        }
        composable(route = "reminderEdit"){
            reminderEdit(navController = appState.navController)
        }
        composable(route = "maps"){
            ReminderLocation(navController = appState.navController)
        }
        composable(route = "selectLocation"){
            VirtualLocation(navController = appState.navController)
        }
    }


}