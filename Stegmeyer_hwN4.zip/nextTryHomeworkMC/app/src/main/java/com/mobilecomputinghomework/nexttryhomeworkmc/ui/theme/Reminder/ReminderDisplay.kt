package com.mobilecomputinghomework.reminderLogin.ui.theme.Reminder

import android.content.Context
import androidx.compose.foundation.ScrollState
import  androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.accompanist.insets.systemBarsPadding
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder.ReminderViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.android.gms.maps.model.LatLng
import com.mobilecomputinghomework.nexttryhomeworkmc.data.entity.Reminder
import com.mobilecomputinghomework.nexttryhomeworkmc.ui.theme.Reminder.setReminderNotification
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun ReminderDisplay(
    onBackPress: ()-> Unit,
    navController: NavController,
    viewModel: ReminderViewModel = viewModel(),


    ){
    val title = rememberSaveable {mutableStateOf("")}
    val message = rememberSaveable {mutableStateOf("")}
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val location_x = rememberSaveable{ mutableStateOf("") }
    val location_y = rememberSaveable{mutableStateOf("")}
    val date = rememberSaveable{mutableStateOf("")}
    val remindUponOccurrence = rememberSaveable{mutableStateOf(true)}

    val latlng = navController
        .currentBackStackEntry
        ?.savedStateHandle
        ?.getLiveData<LatLng>("location_data")
        ?.value

    Surface{
        Column (
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(state = rememberScrollState(), enabled = true)
                ){
            TopAppBar() {
                IconButton(onClick = onBackPress) {
                    Icon(imageVector = Icons.Default.ArrowBack,
                    contentDescription = "null")

                }
                Text(text = "Reminder")
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top,
                    modifier = Modifier.padding(12.dp))
            {
                OutlinedTextField(value = title.value, onValueChange = {title.value = it},
                    label = {Text(text = "Title")},
                    modifier = Modifier.fillMaxWidth()
                    )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(value = message.value, onValueChange = {message.value = it},
                    label = {Text(text = "Message")},
                    modifier = Modifier.fillMaxWidth()
                )

                //Location
//                Spacer(modifier = Modifier.height(10.dp))
//                OutlinedTextField(value = location_x.value, onValueChange = {data -> location_x.value = data},
//                    label = { Text("location x") },
//                    modifier = Modifier.fillMaxWidth(),
//                    keyboardOptions = KeyboardOptions(
//                        keyboardType = KeyboardType.Number
//                    )
//                )
//                Spacer(modifier = Modifier.height(10.dp))
//                OutlinedTextField(value = location_y.value, onValueChange = {data -> location_y.value = data},
//                    label = { Text("location y") },
//                    modifier = Modifier.fillMaxWidth(),
//                    keyboardOptions = KeyboardOptions(
//                        keyboardType = KeyboardType.Number
//                    )
//                )





                //Input Date
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(value = date.value, onValueChange = {data -> date.value = data},
                    label = { Text("Enter date in format: yyyy-MM-dd HH:mm") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                    )
                )

                //Location
                Spacer(modifier = Modifier.height(10.dp))
                if(latlng == null){
                    OutlinedButton(onClick = { navController.navigate("maps")},modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Location")
                    }
                } else {
                    Text(
                        text = "Lat: ${latlng.latitude}, \n Lng: ${latlng.longitude}"
                    )
                }

                //Remind upon occurence
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Remind upon occurrence")
                    Checkbox(checked = remindUponOccurrence.value, onCheckedChange = {data->remindUponOccurrence.value = data})
                }


                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    enabled = true,
                    onClick = {
                        val sharedPreferences = context.getSharedPreferences("login", Context.MODE_PRIVATE)
                        val id = sharedPreferences.getString("creatorID","1")

                        //Brauche ich vermutlich nochmal woanders
                        val pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                        //val time = LocalDateTime.parse(date.value, pattern)

                        val current = LocalDateTime.now()
                        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                        val now = current.format(formatter)


                        coroutineScope.launch {

                            if (id != null ) {
                                if(date.value == "" && latlng == null){
                                    val reminder = Reminder(creator_Id = id.toLong(), reminder_Title = title.value, reminder_Message = message.value, time = null, location_x = null, location_y = null, reminder_Seen = true, creation_time = now, reminder_Nofification = remindUponOccurrence.value)
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }else if(date.value == ""){
                                    val reminder = Reminder(creator_Id = id.toLong(), reminder_Title = title.value, reminder_Message = message.value, time = null, location_x = latlng?.longitude, location_y = latlng?.latitude, reminder_Seen = false, creation_time = now, reminder_Nofification = remindUponOccurrence.value)
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }else if (latlng == null){
                                    val reminder = Reminder(creator_Id = id.toLong(), reminder_Title = title.value, reminder_Message = message.value,time = date.value, location_x = null, location_y = null, reminder_Seen = false, creation_time = now, reminder_Nofification = remindUponOccurrence.value)
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }else {
                                    val reminder = Reminder(creator_Id = id.toLong(), reminder_Title = title.value, reminder_Message = message.value,time = date.value, location_x = latlng?.longitude, location_y = latlng?.latitude, reminder_Seen = false, creation_time = now, reminder_Nofification = remindUponOccurrence.value)
                                    viewModel.saveReminder(
                                        reminder
                                    )
                                }




                            }
                        }


                        navController.navigate("Main")



                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save reminder")
                }

                Spacer(modifier = Modifier.height(500.dp))
            }

        }

    }

}
